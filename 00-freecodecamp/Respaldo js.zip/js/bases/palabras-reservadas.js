// Palabras reservadas
// uso especifico para cual fueron echas

// let const = 123;     variable reservada