// formas de ingreso de informacion de usuario

// instrucciones bloqueantes
// alert('Hola mundo');                                        // alerta
// let nombre = prompt('¿cual es tu nombre?', 'sin nombre');    //obtiene un dato del usuario
// console.log(nombre);

// const seleccion = confirm('estas seguro?');
// console.log(seleccion);

console.log(global);
