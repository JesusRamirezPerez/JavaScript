// datos priitivos
  // Boolean
  // Null
  // undefined
  // Number
  // String
  // Symbol

let nombre = 'Peter Parker';
console.log(nombre);

nombre = 'Ben Parker';
console.log(nombre);

nombre = 'Tia May';

// typeof da el tipo de dato de la variable
console.log(typeof nombre);     // retorna "string"

let esMarvel = true;
console.log(typeof esMarvel);

let edad = 33;
console.log(typeof edad);

let superPoder;
console.log(superPoder);

let soyNull = null;
console.log(typeof soyNull);

let symbol1 = Symbol('a');
let symbol2 = Symbol('a');
console.log(typeof symbol1);
console.log(symbol1 == symbol2);





