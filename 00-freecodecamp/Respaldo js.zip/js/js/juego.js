 /* 
2c = dos de clubs (treboles)
2d = dos de diamons (diamantes)
2h = dos de hearts (corazones)
2s = dos de spades (espadas)
*/


let deck = [];
const tipos = ['C', 'D', 'H', 'S',];
const especiales = ['A', 'J', 'K', 'Q',];

const crearDeck = (  )=>{
  for (let i = 2; i <= 10; i++){
    for (let tipo of tipos){
      deck.push(i + tipo);
    }
  }
  for (let tipo of tipos){
    for (let esp of especiales){
      deck.push( esp + tipo);
    }
  }
  deck = _.shuffle(deck);
  console.log(deck); 
  return deck;
}
crearDeck();

// Esta funcion me permite tomar una carta
const pedirCarta = () => {
  if (deck.length === 0){
    throw 'No hay mas caras en el deck';        // manda una mensaje de eeror directo a consola
  }
  const carta = deck.shift();
  console.log(deck); 
  return carta;
}
pedirCarta();

const valorCarta = (carta) =>{
  const valor = carta.substring(0, carta.length-1);   // substring regresa un arreglo a partir de un arreglo base  esto con la condicion de inicio y final
  // console.log({valor});  
  if( isNaN(valor) ){                                 // evalua si el parametro es un numero                             
    console.log('no es un numero'); 
  } else {
    console.log('es un numero'); 
  }
}

valorCarta('10D')