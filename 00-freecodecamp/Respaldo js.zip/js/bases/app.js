//alert('hola desde app.js');

console.log('hola mundo'); 

let a = 10,
    b = 20,
    c = 30,
    d = 40,
    e = 'hola ',
    f = 'Spiderman'
    x = a + b;

const saludo = e + f;

console.log(x);       // console log
console.warn(x);      // warning
console.error(x);     // error

// %c agrega codigo CSS a la funcion
// console.log('%c mensaje', 'estilos css:');
console.log('%c Ese es un console.log con estilo', 'color: red; font-size: 19; font-weight: bold');       // console log
console.table({a, b, c, d});

e = 'hola de nuevo';

// let outerWidth = 1000000;
// let outerHeight = 600;
